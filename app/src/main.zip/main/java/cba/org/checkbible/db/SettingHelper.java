package cba.org.checkbible.db;

/**
 * Created by jinhwan.na on 2016-10-13.
 */

public class SettingHelper {
}
